@extends('layout.app')


@section('content')
<style type="text/css">
	.px{
		padding-top: 40px;
		margin: 20px;
	}
</style>
<div class="container">

<div class="row justify-content-center">
	<div class="col-lg-7 text-center card px">
		<form method="post" enctype="multipart/form-data" action="{{Route('blog.store')}}">
			@csrf
			<div class="form-group">
				<label>Blog Title</label>
				<input type="text" name="title" placeholder="Blog Title" required class="form-control">
			</div>
			<div class="form-group">
				<label>Blog Content</label>
				<textarea name="content" placeholder="Blog Content" required class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Blog Image</label>
				<input type="file" name="image" required class="form-control">
			</div>
			<div class="form-group">
				<button type="submit" name="ok" class="btn btn-success">Post</button>
			</div>
		</form> 
	</div>

	<div class="col-lg-12 text-center">
		@if(isset($blogs))

		@if(count($blogs)>0)

		<div class="row" style="margin-bottom: 18px;">
			@foreach($blogs as $blog)
			<div class="col-lg-6" style="margin-bottom: 10px;margin-top:10px;">
				<div class="card">
					<div class="card-title bg-dark text-white">
						<p id="title{{$blog->id}}">{{$blog->title}}</p>
					</div>
					<div class="card-body text-center">
						<img src="{{$blog->image}}" id="image{{$blog->id}}" style="height: 200px; " class="img-fluid">
						<input type="file" id="image_file{{$blog->id}}" name="image" class="form-control" onchange="imageSelected('{{$blog->id}}')" style="display: none">
						<hr>
						<p id="content{{$blog->id}}">{{$blog->content}}</p>

						<small>Author: {{$blog->user->name}}</small>
						<small>Pubished on {{$blog->created_at}}</small>
					<br>
					@if(Session('user')[0]->id==$blog->user->id)
					<br>
						<form method="post" action="{{Route('blog.destroy',$blog->id)}}">
							@csrf
							@method('DELETE')
						<button class="btn btn-danger" onclick="return confirm('Sure about that?')"><i class="fa fa-trash"></i></button>
						<button id="ebtn{{$blog->id}}" type="button" onclick="editBlog(this,'{{$blog->id}}')" class="btn btn-success"><i class="fa fa-edit"></i></button>
						</form>
						<br>
						<a id="s{{$blog->id}}" onclick="save('{{$blog->id}}')" class="btn btn-warning" style="display: none">Save</a>
						@endif
					</div>
				</div>
			</div>
			@endforeach


		</div>

		@else
		<p> No Blogs found </p>
		@endif


		@endif
	</div>
</div>

</div>
@endsection