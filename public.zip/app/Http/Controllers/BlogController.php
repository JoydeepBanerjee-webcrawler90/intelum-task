<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Blog;

use Session;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $request->validate([
            "title"=>"required",
            "content"=>"required",
        ]);

        $user_id = Session('user')[0]->id ?? die(0);
        $nc = new Blog;
        $nc->title = $request->title;
        $nc->content = $request->content;
        $nc->user_id = $user_id;

         if(!empty($request->file('image')))
        {
            $file = $request->file('image');
            $Extension = $file->getClientOriginalExtension();
            $filename = time().'.'.$Extension;
            $destinationPath = 'blog_imgs';
            $d = $file->move($destinationPath,$filename);
            $nc->image = $d;
        }

        $nc->save();
        Session::flash('success','Blog Added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
  
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'title'=>'required',
            'content'=>'required'
        ]);

      //  return var_dump($request->title);
       // return var_dump($_FILES);
        $d = '';
          if(!empty($request->file('image')))
        {
            $file = $request->file('image');
            $Extension = $file->getClientOriginalExtension();
            $filename = time().'.'.$Extension;
            $destinationPath = 'blog_imgs';
            $d = $file->move($destinationPath,$filename);
            $update = Blog::where('id',$id)->update([
            'title'=>$request->title,
            'content'=>$request->content,
            'image'=>$d

        ]);
            
        }
        else
        {
             $update = Blog::where('id',$id)->update([
            'title'=>$request->title,
            'content'=>$request->content,

        ]);
        }

        return 1;
       





    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        Blog::where('id',$id)->delete();

        return redirect()->back()->with('success','Blog deleted successfully!');
    }
}
