<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\Models\User;
use App\Models\Blog;

class UserController extends Controller
{
    //
    public function index(){

    	if(Session::has('user'))
    	{
    		$blogs = Blog::all();
    		return view('pages.index')->with('blogs',$blogs);
    	}
    	else
    	{
    		return view('welcome');
    	}

    }

    public function register(Request $request){

    	$request->validate([
    		'name'=>'required|max:255',
    		'email'=>'required',
    		'password'=>'required',
    		'cpassword'=>'min:6|same:password'
    	]);

    	$v = User::where('email',$request->email)->get();

    	if(count($v)==0)
    	{
    	$new_user = new User;
    	$new_user->name = $request->name;
    	$new_user->email = $request->email;
    	$new_user->password = $request->password;
    	$new_user->save();
    	$v = User::where('email',$request->email)->get();

    	}

    	Session::put('user',$v);

       	return redirect()->to('/')->with('message','Registered successfully');

    }


    public function login(Request $request){

    	$request->validate([

    		'email'=>'required',
    		'password'=>'required',
    		
    	]);

    	$v = User::where('email',$request->email)->where('password',$request->password)->get();

    	if(count($v)==0)
    	{
    	
    			return redirect()->to('/')->with('message','Invalid Credentials');
    	}

    	Session::put('user',$v);

       	return redirect()->to('/')->with('message','Logged In');

    }

    public function logout(){
    	$session = Session::forget('user');
    	return redirect()->back();
    }





}
