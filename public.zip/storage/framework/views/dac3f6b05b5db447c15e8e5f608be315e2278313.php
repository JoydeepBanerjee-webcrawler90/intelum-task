<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <!-- Styles -->
     

        <style>
            body {
                font-family: 'Nunito';
            }
            body{
  /*background-color: #1cbb9b;*/
   background: #50a5a2;
    background-image: -webkit-gradient(linear, left top, right top, from(#50a5a2), to(#52cba2));
    background-image: -webkit-linear-gradient(left, #50a5a2, #52cba2);
    background-image: -moz-linear-gradient(left, #50a5a2, #52cba2);
    background-image: -o-linear-gradient(left, #50a5a2, #52cba2);
    background-image: linear-gradient(to right, #50a5a2, #52cba2);
}
.login-box{
  position:relative;
  margin: 10px auto;
  width: 500px;
  height:auto;
  background-color: #fff;
  padding: 10px;
  border-radius: 3px;
  -webkit-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
-moz-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
transition: 0.5s;

}

.login-box:hover{
    cursor: pointer;
    transform: translateY(-8px);
}
.lb-header{
  position:relative;
  color: white;
  background-color: #379;
  margin: 5px 5px 10px 5px;
  padding-bottom:10px;
  padding-top: 10px;
  border-bottom: 1px solid #eee;
  box-shadow: 0 0 4px rgba(0,0,0,0.22);
  text-align:center;
  height:auto;
}
.lb-header a{
  margin: 0 25px;
  padding: 0 20px;
  text-decoration: none;
  color: #666;
  font-weight: bold;
  font-size: 15px;
  -webkit-transition: all 0.1s linear;
  -moz-transition: all 0.1s linear;
  transition: all 0.1s linear;
}
.lb-header .active{
  color: #029f5b;
  font-size: 18px;
}
.social-login{
  position:relative;
  float: left;
  width: 100%;
  height:auto;
  padding: 10px 0 15px 0;
  border-bottom: 1px solid #eee;
}
.social-login a{
  position:relative;
  float: left;
  width:calc(40% - 8px);
  text-decoration: none;
  color: #fff;
  border: 1px solid rgba(0,0,0,0.05);
  padding: 12px;
  border-radius: 2px;
  font-size: 12px;
  text-transform: uppercase;
  margin: 0 3%;
  text-align:center;
}
.social-login a i{
  position: relative;
  float: left;
  width: 20px;
  top: 2px;
}
.social-login a:first-child{
  background-color: #49639F;
}
.social-login a:last-child{
  background-color: #DF4A32;
}
.email-login,.email-signup{
  position:relative;
  float: left;
  width: 100%;
  height:auto;
  margin-top: 20px;
  text-align:center;
}
.u-form-group{
  width:100%;
  margin-bottom: 10px;
}
.u-form-group input[type="email"],
.u-form-group input[type="password"],
.u-form-group input[type="text"]{
  width: calc(70% - 22px);
  height:45px;
  outline: none;
  border: 1px solid #ddd;
  padding: 0 10px;
  border-radius: 2px;
  
  transition: 0.5s;
  color: #333;
  font-size:0.8rem;
  -webkit-transition:all 0.1s linear;
  -moz-transition:all 0.1s linear;
  transition:all 0.1s linear;
}


.u-form-group input:focus{
box-shadow: 0 0 4px rgba(0,0,0,.22);
  border-color: #358efb;
}
.u-form-group button{
  width:50%;
  background-color: #1CB94E;
  border: none;
  outline: none;
  color: #fff;
  font-size: 14px;
  font-weight: normal;
  padding: 14px 0;
  border-radius: 2px;
  text-transform: uppercase;
}
.forgot-password{
  width:50%;
  text-align: left;
  text-decoration: underline;
  color: #888;
  font-size: 0.75rem;
}
.login-box{
    overflow: hidden;
    margin-top:100px;
}
#login-box-link,#signup-box-link{
    font-size: 19px;
    background-color: #379;
    color:white;
}
        </style>
    </head>
    <body class="antialiased">
        
  <div class="login-box">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="lb-header">
        <h2 class="text-center">Welcome to Intlum Blog</h2>
        <br>
      <a href="#" class="active" id="login-box-link">Login</a>
      <a href="#" id="signup-box-link">Sign Up</a>
    </div>
 <!--    <div class="social-login">
      <a href="#">
        <i class="fa fa-facebook fa-lg"></i>
        Login in with facebook
      </a>
      <a href="#">
        <i class="fa fa-google-plus fa-lg"></i>
        log in with Google
      </a>
    </div> -->
    <form class="email-login" method="post" action="<?php echo e(Route('login')); ?>">
        <?php echo csrf_field(); ?>
      <div class="u-form-group">
        <input type="email" name="email" placeholder="Email"/>
      </div>
      <div class="u-form-group">
        <input type="password" name="password" placeholder="Password"/>
      </div>
      <div class="u-form-group">
        <button type="submit" name="login">Log in</button>
      </div>
      <div class="u-form-group">
        <a href="#" class="forgot-password">Forgot password?</a>
      </div>
    </form>
    <form class="email-signup" method="post" action="<?php echo e(Route('register')); ?>">
        <?php echo csrf_field(); ?>
         <div class="u-form-group">
        <input type="text" name="name" placeholder="Name"/>
      </div>
      <div class="u-form-group">
        <input type="email" name="email" placeholder="Email"/>
      </div>
      <div class="u-form-group">
        <input type="password" name="password" placeholder="Password"/>
      </div>
      <div class="u-form-group">
        <input type="password" name="cpassword" placeholder="Confirm Password"/>
      </div>
      <div class="u-form-group">
        <button type="submit" name="ok">Sign Up</button>
      </div>
    </form>
  </div>
  <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(".email-signup").hide();
$("#signup-box-link").click(function(){
  $(".email-login").fadeOut(100);
  $(".email-signup").delay(100).fadeIn(100);
  $("#login-box-link").removeClass("active");
  $("#signup-box-link").addClass("active");
});
$("#login-box-link").click(function(){
  $(".email-login").delay(100).fadeIn(100);;
  $(".email-signup").fadeOut(100);
  $("#login-box-link").addClass("active");
  $("#signup-box-link").removeClass("active");
});
</script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/welcome.blade.php ENDPATH**/ ?>