


<?php $__env->startSection('content'); ?>
<style type="text/css">
	.px{
		padding-top: 40px;
		margin: 20px;
	}
</style>
<div class="container">

<div class="row justify-content-center">
	<div class="col-lg-7 text-center card px">
		<form method="post" enctype="multipart/form-data" action="<?php echo e(Route('blog.store')); ?>">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label>Blog Title</label>
				<input type="text" name="title" placeholder="Blog Title" required class="form-control">
			</div>
			<div class="form-group">
				<label>Blog Content</label>
				<textarea name="content" placeholder="Blog Content" required class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Blog Image</label>
				<input type="file" name="image" required class="form-control">
			</div>
			<div class="form-group">
				<button type="submit" name="ok" class="btn btn-success">Post</button>
			</div>
		</form> 
	</div>

	<div class="col-lg-12 text-center">
		<?php if(isset($blogs)): ?>

		<?php if(count($blogs)>0): ?>

		<div class="row" style="margin-bottom: 18px;">
			<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-6" style="margin-bottom: 10px;margin-top:10px;">
				<div class="card">
					<div class="card-title bg-dark text-white">
						<p id="title<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></p>
					</div>
					<div class="card-body text-center">
						<img src="<?php echo e($blog->image); ?>" id="image<?php echo e($blog->id); ?>" style="height: 200px; " class="img-fluid">
						<input type="file" id="image_file<?php echo e($blog->id); ?>" name="image" class="form-control" onchange="imageSelected('<?php echo e($blog->id); ?>')" style="display: none">
						<hr>
						<p id="content<?php echo e($blog->id); ?>"><?php echo e($blog->content); ?></p>

						<small>Author: <?php echo e($blog->user->name); ?></small>
						<small>Pubished on <?php echo e($blog->created_at); ?></small>
					<br>
					<?php if(Session('user')[0]->id==$blog->user->id): ?>
					<br>
						<form method="post" action="<?php echo e(Route('blog.destroy',$blog->id)); ?>">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
						<button class="btn btn-danger" onclick="return confirm('Sure about that?')"><i class="fa fa-trash"></i></button>
						<button id="ebtn<?php echo e($blog->id); ?>" type="button" onclick="editBlog(this,'<?php echo e($blog->id); ?>')" class="btn btn-success"><i class="fa fa-edit"></i></button>
						</form>
						<br>
						<a id="s<?php echo e($blog->id); ?>" onclick="save('<?php echo e($blog->id); ?>')" class="btn btn-warning" style="display: none">Save</a>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</div>

		<?php else: ?>
		<p> No Blogs found </p>
		<?php endif; ?>


		<?php endif; ?>
	</div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/index.blade.php ENDPATH**/ ?>