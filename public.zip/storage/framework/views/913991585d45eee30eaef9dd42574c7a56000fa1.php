<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <!-- Styles -->
     
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body {
                font-family: 'Nunito';
            }
            body{
  /*background-color: #1cbb9b;*/
   background: #50a5a2;
    background-image: -webkit-gradient(linear, left top, right top, from(#50a5a2), to(#52cba2));
    background-image: -webkit-linear-gradient(left, #50a5a2, #52cba2);
    background-image: -moz-linear-gradient(left, #50a5a2, #52cba2);
    background-image: -o-linear-gradient(left, #50a5a2, #52cba2);
    background-image: linear-gradient(to right, #50a5a2, #52cba2);
}
.login-box{
  position:relative;
  margin: 10px auto;
  width: 500px;
  height:auto;
  background-color: #fff;
  padding: 10px;
  border-radius: 3px;
  -webkit-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
-moz-box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.33);
transition: 0.5s;

}

.login-box:hover{
    cursor: pointer;
    transform: translateY(-8px);
}
.lb-header{
  position:relative;
  color: white;
  background-color: #379;
  margin: 5px 5px 10px 5px;
  padding-bottom:10px;
  padding-top: 10px;
  border-bottom: 1px solid #eee;
  box-shadow: 0 0 4px rgba(0,0,0,0.22);
  text-align:center;
  height:auto;
}
.lb-header a{
  margin: 0 25px;
  padding: 0 20px;
  text-decoration: none;
  color: #666;
  font-weight: bold;
  font-size: 15px;
  -webkit-transition: all 0.1s linear;
  -moz-transition: all 0.1s linear;
  transition: all 0.1s linear;
}
.lb-header .active{
  color: #029f5b;
  font-size: 18px;
}
.social-login{
  position:relative;
  float: left;
  width: 100%;
  height:auto;
  padding: 10px 0 15px 0;
  border-bottom: 1px solid #eee;
}
.social-login a{
  position:relative;
  float: left;
  width:calc(40% - 8px);
  text-decoration: none;
  color: #fff;
  border: 1px solid rgba(0,0,0,0.05);
  padding: 12px;
  border-radius: 2px;
  font-size: 12px;
  text-transform: uppercase;
  margin: 0 3%;
  text-align:center;
}
.social-login a i{
  position: relative;
  float: left;
  width: 20px;
  top: 2px;
}
.social-login a:first-child{
  background-color: #49639F;
}
.social-login a:last-child{
  background-color: #DF4A32;
}
.email-login,.email-signup{
  position:relative;
  float: left;
  width: 100%;
  height:auto;
  margin-top: 20px;
  text-align:center;
}
.u-form-group{
  width:100%;
  margin-bottom: 10px;
}
.u-form-group input[type="email"],
.u-form-group input[type="password"],
.u-form-group input[type="text"]{
  width: calc(70% - 22px);
  height:45px;
  outline: none;
  border: 1px solid #ddd;
  padding: 0 10px;
  border-radius: 2px;
  
  transition: 0.5s;
  color: #333;
  font-size:0.8rem;
  -webkit-transition:all 0.1s linear;
  -moz-transition:all 0.1s linear;
  transition:all 0.1s linear;
}


.u-form-group input:focus{
box-shadow: 0 0 4px rgba(0,0,0,.22);
  border-color: #358efb;
}
.u-form-group button{
  width:50%;
  background-color: #1CB94E;
  border: none;
  outline: none;
  color: #fff;
  font-size: 14px;
  font-weight: normal;
  padding: 14px 0;
  border-radius: 2px;
  text-transform: uppercase;
}
.forgot-password{
  width:50%;
  text-align: left;
  text-decoration: underline;
  color: #888;
  font-size: 0.75rem;
}
.login-box{
    overflow: hidden;
    margin-top:100px;
}
#login-box-link,#signup-box-link{
    font-size: 19px;
    background-color: #379;
    color:white;
}
        </style>

    </head>
    <body class="antialiased">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"><?php echo e(Session('user')[0]->name); ?></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/menu-ordering">Menu Ordering</a>
      </li>
      <li class="nav-item">
        <form method="post" action="/logout1">
        	<?php echo csrf_field(); ?>
        	<button type="submit" style="padding: 5px;border: none;background-color: none;margin-top: 5px;"><i class="fa fa-sign-out"></i> Logout</button>
        </form>
      </li>
     <!--  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li> -->
     <!--  <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li> -->
    </ul>

  <!--   <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
  </div>
</nav>



<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
          
                <li><?php echo e(Session('success')); ?></li>
    
        </ul>
    </div>
<?php endif; ?>

<div class="main">
	<?php echo $__env->yieldContent('content'); ?>
	</div>



 <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $(document).ready(function(){

    	function updateToDatabase(idString){
    	   $.ajaxSetup({ headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'}});
    		
    	   $.ajax({
              url:'<?php echo e(url('/menu/update-order')); ?>',
              method:'POST',
              data:{ids:idString},
              success:function(){
                swal('Successfully updated')
               	 //do whatever after success
              }
           })
    	}

        var target = $('.sort_menu');
        target.sortable({
            handle: '.handle',
            placeholder: 'highlight',
            axis: "y",
            update: function (e, ui){
               var sortData = target.sortable('toArray',{ attribute: 'data-id'})
               updateToDatabase(sortData.join(','))
            }
        })
        
    });

	
	function editBlog(ob,id)
	{
		$("#s"+id).slideDown(600);
		$(ob).slideUp(600);

		$("#content"+id).prop('contentEditable',true);
		$("#content"+id).css('background-color','green');
		$("#title"+id).prop('contentEditable',true);
		$("#title"+id).css('background-color','green');
		$("#image_file"+id).slideDown(600);

	}

	function save(id)
	{
		var content = $("#content"+id).text();
		var title = $("#title"+id).text();

		if(content.length==0 || title.length==0) return;
		var formData = new FormData();
		var image =  document.getElementById('image_file'+id);
		var ins = 0;
		ins = image.files.length;
		// if(ins>0)
		// {
		// 	console.log(image.files[0]);
			
		// }
		if(ins>0){
			formData.append("image", image.files[0]);
		}
		formData.append('title',title);
		formData.append('content',content);
		formData.append('id',id);
		$.ajaxSetup({
			headers: {'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'}
		});
		$.ajax(
		{
			url:"/blog/update1/"+id,
			type:"POST",
			data:formData,
			contentType: false, 
       processData: false,
       cache: false,
        xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                    myXhr.upload.addEventListener('progress',progressBar, false);
                }
                return myXhr;
        },
			error:(res)=>{
				swal(res.responseText);
			},
			success:(res)=>{
				if(res==1)
				{
					swal("Blog update success!");
					$("#s"+id).slideUp(600);
					$("#ebtn"+id).slideDown(600);
					$("#content"+id).prop('contentEditable',false);
		$("#content"+id).css('background-color','white');
		$("#title"+id).prop('contentEditable',false);
		$("#title"+id).css('background-color','#333');
		$("#image_file"+id).slideUp(600);
				}
				else{
					swal(res);
				}
			}

		});
		



	}

	function progressBar(e){

    if(e.lengthComputable){
        var max = e.total;
        var current = e.loaded;

        var Percentage = (current * 100)/max;
        Percentage = parseInt(Percentage);
        console.log(Percentage);
         swal({
          title:" "+Percentage+ "% updating just a moment",
          closeOnClickOutside: false,
          buttons:false
        });
       
    
        // if(Percentage >= 100)
        // {
        //    // process completed  

        // $("#upload-progress-report").html("Upload complete, All Answers submitted successfully.");
        // }
    }  
 }

	function imageSelected(id){
        var input = document.getElementById('image_file'+id);
        var ins = input.files[0].length;
      
        console.log(input.files[0]);

        if (input.files[0]) {
          var reader = new FileReader();
          filesize = input.files[0].size;
          var flag = 1;
          if(filesize>3382455)
          {
            swal("File Size Error","File size must be less than 3 MB","error");
            
            input.value = "";
            flag=0;
            $(".loaderx").hide();
            return false;

          } 
          reader.onload = function (e) {

            if(flag){
             // $(".loaderx").show();
              $("#image"+id).prop('src',e.target.result);
            }
          };
         
          reader.readAsDataURL(input.files[0]);
        

        }

      

    }
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layout/app.blade.php ENDPATH**/ ?>